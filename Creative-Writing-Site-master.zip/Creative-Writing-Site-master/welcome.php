<?php
 echo "Welcome to Wordly! A verification link has been sent to the email you provided :)";
?>